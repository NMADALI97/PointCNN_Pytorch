# Pytorch_PointCNN

## PointCNN Usage

* ### Classification
  * #### ModelNet40
  ```
  python3 dataset/download_datasets.py -f [path to data folder] -d modelnet
  CUDA_VISIBLE_DEVICES=[your available gpu] python3 run.py
  ```

* ### Notification
 I 'm busy with my homework so I can't maintain this repository. Anyone interested in contributing to the repository is welcome.